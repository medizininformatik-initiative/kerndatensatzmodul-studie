# mii-exa-studie-evidence-variable-age-restriction - MII Implementation Guide Medizinisches Forschungsvorhaben v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-studie-evidence-variable-age-restriction**

## Beispiel EvidenceVariable: mii-exa-studie-evidence-variable-age-restriction

-------

**German**

-------

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html)

**status**: Active

> **characteristic****description**: Höchstalter**definition**: kein Höchstalter**exclude**: false

> **characteristic****description**: Mindestalter**definition**: 18 Jahre**exclude**: false



## Resource Content

```json
{
  "resourceType" : "EvidenceVariable",
  "id" : "mii-exa-studie-evidence-variable-age-restriction",
  "meta" : {
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "status" : "active",
  "characteristic" : [{
    "description" : "Höchstalter",
    "definitionCodeableConcept" : {
      "text" : "kein Höchstalter"
    },
    "exclude" : false
  },
  {
    "description" : "Mindestalter",
    "definitionCodeableConcept" : {
      "text" : "18 Jahre"
    },
    "exclude" : false
  }]
}

```
