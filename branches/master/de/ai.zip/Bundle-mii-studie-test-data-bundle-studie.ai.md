# mii-studie-test-data-bundle-studie - MII Implementation Guide Medizinisches Forschungsvorhaben v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-studie-test-data-bundle-studie**

## Beispiel Bundle: mii-studie-test-data-bundle-studie



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-studie-test-data-bundle-studie",
  "meta" : {
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "type" : "transaction",
  "timestamp" : "2025-12-04T12:00:00+00:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Dokument/mii-exa-studie-dokument",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "mii-exa-studie-dokument",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-dokument"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"DocumentReference_mii-exa-studie-dokument\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference mii-exa-studie-dokument</b></p><a name=\"mii-exa-studie-dokument\"> </a><a name=\"hcmii-exa-studie-dokument\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-dokument.html\">MII PR Studie Dokument</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Current</p><p><b>author</b>: <a href=\"Organization-mii-exa-studie-author.html\">Organization Example Organization for Author</a></p><p><b>custodian</b>: <a href=\"Organization-mii-exa-studie-custodian.html\">Organization Example Organization for Custodian</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Size</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>pdf</td><td><a href=\"https://example.com/fhir/Binary/document\">https://example.com/fhir/Binary/document</a></td><td>2000</td><td>Beispiel Dokument</td></tr></table></blockquote><h3>Contexts</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Related</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"ResearchStudy-mii-exa-studie-cohort.html\">ResearchStudy LIFE-Adult-Study</a></td></tr></table></div></div>"
      },
      "status" : "current",
      "author" : [{
        "reference" : "Organization/mii-exa-studie-author"
      }],
      "custodian" : {
        "reference" : "Organization/mii-exa-studie-custodian"
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/pdf",
          "url" : "https://example.com/fhir/Binary/document",
          "size" : 2000,
          "title" : "Beispiel Dokument"
        }
      }],
      "context" : {
        "related" : [{
          "reference" : "ResearchStudy/mii-exa-studie-cohort"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Dokument"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_EinAuschlussKriterium/mii-exa-studie-ein-auschluss-kriterium",
    "resource" : {
      "resourceType" : "EvidenceVariable",
      "id" : "mii-exa-studie-ein-auschluss-kriterium",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-ein-auschluss-kriterium"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"EvidenceVariable_mii-exa-studie-ein-auschluss-kriterium\"> </a><p class=\"res-header-id\"><b>Generated Narrative: EvidenceVariable mii-exa-studie-ein-auschluss-kriterium</b></p><a name=\"mii-exa-studie-ein-auschluss-kriterium\"> </a><a name=\"hcmii-exa-studie-ein-auschluss-kriterium\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-ein-auschluss-kriterium.html\">MII PR Studie EinAuschlussKriterium</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>status</b>: Active</p><blockquote><p><b>characteristic</b></p><p><b>MII EX Studie Backport definitionReference</b>: <a href=\"EvidenceVariable-mii-exa-studie-evidence-variable-age-restriction.html\">EvidenceVariable: status = active</a></p><p><b>description</b>: Altersbeschränkung</p><p><b>definition</b>: <span title=\"Codes:\">Altersbeschränkung</span></p></blockquote><blockquote><p><b>characteristic</b></p><p><b>MII EX Studie Backport definitionCanonical</b>: <code>https://www.medizininformatik-initiative.de/fhir/EvidenceVariable/administrative-gender</code></p><p><b>description</b>: Geschlecht</p><p><b>definition</b>: <span title=\"Codes:\">Alle</span></p><p><b>exclude</b>: false</p></blockquote><blockquote><p><b>characteristic</b></p><p><b>MII EX Studie Backport linkId</b>: aa83ebf3-cfe4-4ed6-aa71-0779c28e85a2</p><p><b>description</b>: Kognitive Fatigue (WeiMUS kognitive Skala &gt;= 17)</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: false</p></blockquote><blockquote><p><b>characteristic</b></p><p><b>MII EX Studie Backport linkId</b>: 8e8f63ff-65f1-40cd-bf79-da83d7fb4e09</p><p><b>description</b>: Positiver SARS-CoV-2(COVID-19)-Befund; mind. 3 Monate alt</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: false</p></blockquote><blockquote><p><b>characteristic</b></p><blockquote><p><b>MII EX Studie Backport DefinitionByCombination</b></p><ul><li>code: any-of</li><li>characteristic: aa83ebf3-cfe4-4ed6-aa71-0779c28e85a2</li><li>characteristic: 8e8f63ff-65f1-40cd-bf79-da83d7fb4e09</li></ul></blockquote><p><b>description</b>: Weitere Einschlusskriterien</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: false</p></blockquote><blockquote><p><b>characteristic</b></p><p><b>description</b>: diagnostizierte Depressionen, Angststörungen, andere psychiatrische Erkrankungen</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: true</p></blockquote><blockquote><p><b>characteristic</b></p><p><b>description</b>: Einnahme von Antidepressiva, Opioiden, Antikonvulsiva</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: true</p></blockquote><blockquote><p><b>characteristic</b></p><p><b>description</b>: weitere neurologische Erkrankungen</p><p><b>definition</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/data-absent-reason unknown}\">Unknown</span></p><p><b>exclude</b>: true</p></blockquote><blockquote><p><b>characteristic</b></p><blockquote><p><b>MII EX Studie Backport DefinitionByTypeAndValue</b></p><ul><li>type: <span title=\"Codes:{http://snomed.info/sct 424144002}\">Current chronological age</span></li><li>value: &gt;=18 year<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codea = 'a')</span></li></ul></blockquote><p><b>description</b>: Alter mindestens 18 Jahre</p><p><b>definition</b>: <span title=\"Codes:\">Mindestalter</span></p><p><b>exclude</b>: false</p></blockquote></div></div>"
      },
      "status" : "active",
      "characteristic" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.definitionReference",
          "valueReference" : {
            "reference" : "EvidenceVariable/mii-exa-studie-evidence-variable-age-restriction"
          }
        }],
        "description" : "Altersbeschränkung",
        "definitionCodeableConcept" : {
          "text" : "Altersbeschränkung"
        }
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.definitionCanonical",
          "valueCanonical" : "https://www.medizininformatik-initiative.de/fhir/EvidenceVariable/administrative-gender"
        }],
        "description" : "Geschlecht",
        "definitionCodeableConcept" : {
          "text" : "Alle"
        },
        "exclude" : false
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.linkId",
          "valueId" : "aa83ebf3-cfe4-4ed6-aa71-0779c28e85a2"
        }],
        "description" : "Kognitive Fatigue (WeiMUS kognitive Skala >= 17)",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : false
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.linkId",
          "valueId" : "8e8f63ff-65f1-40cd-bf79-da83d7fb4e09"
        }],
        "description" : "Positiver SARS-CoV-2(COVID-19)-Befund; mind. 3 Monate alt",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : false
      },
      {
        "extension" : [{
          "extension" : [{
            "url" : "code",
            "valueCode" : "any-of"
          },
          {
            "url" : "characteristic",
            "valueId" : "aa83ebf3-cfe4-4ed6-aa71-0779c28e85a2"
          },
          {
            "url" : "characteristic",
            "valueId" : "8e8f63ff-65f1-40cd-bf79-da83d7fb4e09"
          }],
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.definitionByCombination"
        }],
        "description" : "Weitere Einschlusskriterien",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : false
      },
      {
        "description" : "diagnostizierte Depressionen, Angststörungen, andere psychiatrische Erkrankungen",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : true
      },
      {
        "description" : "Einnahme von Antidepressiva, Opioiden, Antikonvulsiva",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : true
      },
      {
        "description" : "weitere neurologische Erkrankungen",
        "definitionCodeableConcept" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/data-absent-reason",
            "code" : "unknown"
          }]
        },
        "exclude" : true
      },
      {
        "extension" : [{
          "extension" : [{
            "url" : "type",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://snomed.info/sct",
                "code" : "424144002",
                "display" : "Current chronological age"
              }]
            }
          },
          {
            "url" : "value",
            "valueQuantity" : {
              "value" : 18,
              "comparator" : ">=",
              "unit" : "year",
              "system" : "http://unitsofmeasure.org",
              "code" : "a"
            }
          }],
          "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-EvidenceVariable.characteristic.definitionByTypeAndValue"
        }],
        "description" : "Alter mindestens 18 Jahre",
        "definitionCodeableConcept" : {
          "text" : "Mindestalter"
        },
        "exclude" : false
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_EinAuschlussKriterium"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Studie/mii-exa-studie-studie",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-studie-studie",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-studie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"ResearchStudy_mii-exa-studie-studie\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-studie-studie</b></p><a name=\"mii-exa-studie-studie\"> </a><a name=\"hcmii-exa-studie-studie\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-studie.html\">MII PR Studie Studie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>MII EX Studie Backport Label</b></p><ul><li>value: Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue</li><li>type: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/title-type scientific}\">Scientific title</span></li></ul></blockquote><blockquote><p><b>MII EX Studie Backport Label</b></p><ul><li>value: Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue</li><li>type: <span title=\"Codes:\">Öffentlicher Titel</span></li></ul></blockquote><p><b>MII EX Studie Akronym</b>: tDCS</p><blockquote><p><b>MII EX Studie Rekrutierung</b></p><ul><li>rekrutierungsstart: 2023-01-12</li><li>rekrutierungsziel: 40</li><li>rekrutierungsstand: 35</li><li>rekrutierungsstand-genauigkeit: good</li><li>rekrutierungsstand-datum: 2023-02-17</li></ul></blockquote><p><b>MII EX Studie Finanzierung</b>: Öffentliche Förderinstitutionen, aus Steuermitteln getragene Institutionen (DFG, BMBF u. a.)</p><blockquote><p><b>MII EX Studie Ethikvotum</b></p><ul><li>status: Zustimmende Bewertung</li><li>kommission: Ethik-Kommission der Otto-von-Guericke-Universität an der Medizinischen Fakultät und am Universitätsklinikum Magdeburg A.ö.R.</li><li>ethiknummer: Az.: 83/18</li></ul></blockquote><p><b>identifier</b>: <code>https://example.com/fhir/sid/drks</code>/DRKS00031294</p><p><b>title</b>: Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue</p><p><b>status</b>: Active</p><p><b>category</b>: <span title=\"Codes:\">interventional</span>, <span title=\"Codes:\">Zufallszuteilung</span></p><p><b>description</b>: </p><div><p>Diese Studie untersucht den Einfluss repetitiver anodaler Gleichstromstimulation des linken dorsolateralen präfrontalen Kortex (dlPFC ) auf subjektive und objektive Kennwerte und assoziierte EEG-Parameter der Fatigue bei Long-COVID Patient*innen. Die Studie ist sham-kontrolliert und doppelt-verblindet.</p>\n</div><blockquote><p><b>arm</b></p><p><b>name</b>: frontale anodale tDCS  (verum condition)</p><p><b>description</b>: vier Stimulationen, jeweils 30 Minuten, 1.5mA über dem linken dlPFC</p></blockquote><blockquote><p><b>arm</b></p><p><b>name</b>: frontale sham tDCS</p><p><b>description</b>: vier Stimulationen, jeweils 30 Minuten</p></blockquote></div></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "value",
          "valueString" : "Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue"
        },
        {
          "url" : "type",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/title-type",
              "code" : "scientific"
            }]
          }
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.label"
      },
      {
        "extension" : [{
          "url" : "value",
          "valueString" : "Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue"
        },
        {
          "url" : "type",
          "valueCodeableConcept" : {
            "text" : "Öffentlicher Titel"
          }
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.label"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-akronym",
        "valueString" : "tDCS"
      },
      {
        "extension" : [{
          "url" : "rekrutierungsstart",
          "valueDate" : "2023-01-12"
        },
        {
          "url" : "rekrutierungsziel",
          "valueInteger" : 40
        },
        {
          "url" : "rekrutierungsstand",
          "valueInteger" : 35
        },
        {
          "url" : "rekrutierungsstand-genauigkeit",
          "valueString" : "good"
        },
        {
          "url" : "rekrutierungsstand-datum",
          "valueDate" : "2023-02-17"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-rekrutierung"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-finanzierung",
        "valueString" : "Öffentliche Förderinstitutionen, aus Steuermitteln getragene Institutionen (DFG, BMBF u. a.)"
      },
      {
        "extension" : [{
          "url" : "status",
          "valueString" : "Zustimmende Bewertung"
        },
        {
          "url" : "kommission",
          "valueString" : "Ethik-Kommission der Otto-von-Guericke-Universität an der Medizinischen Fakultät und am Universitätsklinikum Magdeburg A.ö.R."
        },
        {
          "url" : "ethiknummer",
          "valueString" : "Az.: 83/18"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-ethikvotum"
      }],
      "identifier" : [{
        "system" : "https://example.com/fhir/sid/drks",
        "value" : "DRKS00031294"
      }],
      "title" : "Frontale transkranielle Gleichstromstimulation (tDCS) als potentielle Behandlungsmethode von Long-COVID bedingter Fatigue",
      "status" : "active",
      "category" : [{
        "coding" : [{
          "code" : "interventional"
        }]
      },
      {
        "text" : "Zufallszuteilung"
      }],
      "description" : "Diese Studie untersucht den Einfluss repetitiver anodaler Gleichstromstimulation des linken dorsolateralen präfrontalen Kortex (dlPFC ) auf subjektive und objektive Kennwerte und assoziierte EEG-Parameter der Fatigue bei Long-COVID Patient*innen. Die Studie ist sham-kontrolliert und doppelt-verblindet.",
      "arm" : [{
        "name" : "frontale anodale tDCS  (verum condition)",
        "description" : "vier Stimulationen, jeweils 30 Minuten, 1.5mA über dem linken dlPFC"
      },
      {
        "name" : "frontale sham tDCS",
        "description" : "vier Stimulationen, jeweils 30 Minuten"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Studie"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Cohort/mii-exa-studie-cohort",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-studie-cohort",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-studie"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"ResearchStudy_mii-exa-studie-cohort\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-studie-cohort</b></p><a name=\"mii-exa-studie-cohort\"> </a><a name=\"hcmii-exa-studie-cohort\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-studie.html\">MII PR Studie Studie</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><blockquote><p><b>MII EX Studie Backport Label</b></p><ul><li>value: MII Modul Studie</li></ul></blockquote><blockquote><p><b>MII EX Studie Backport AssociatedParty</b></p><ul><li>role: <span title=\"Codes:{http://example.org/fhir/CodeSystem/associated-party-role sponsor}\">Sponsor</span></li><li>party: <a href=\"Organization-mii-exa-studie-author.html\">Organization Example Organization for Author</a></li></ul></blockquote><blockquote><p><b>MII EX Studie Ethikvotum</b></p><ul><li>status: genehmigt</li><li>kommission: Ethik-Kommission der Medizinischen Fakultät der Universität Leipzig</li><li>ethiknummer: 159-12-21052012</li></ul></blockquote><p><b>MII EX Studie Studienregister</b>: <a href=\"Library-mii-exa-studie-register.html\">DRKS - Deutsches Register Klinischer Studien</a></p><p><b>MII EX Studie Eligibility</b>: <a href=\"EvidenceVariable-mii-exa-studie-ein-auschluss-kriterium.html\">EvidenceVariable: status = active</a></p><p><b>MII EX Studie Akronym</b>: LIFE ADULT</p><blockquote><p><b>MII EX Studie Rekrutierung</b></p><ul><li>rekrutierungsstart: 2009-01-01</li><li>rekrutierungsziel: 10000</li><li>rekrutierungsstand: 10000</li><li>rekrutierungsstand-genauigkeit: good</li><li>rekrutierungsstand-datum: 2022-05-28</li></ul></blockquote><p><b>MII EX Studie Finanzierung</b>: Deutsches Bundesministerium für Bildung und Forschung (BMBF)</p><p><b>identifier</b>: <code>https://example.com/fhir/sid/lha</code>/7Q6PJD8NV3-2</p><p><b>title</b>: LIFE-Adult-Study</p><p><b>partOf</b>: <a href=\"ResearchStudy-mii-exa-studie-reference-study.html\">ResearchStudy Example Reference Study</a></p><p><b>status</b>: Active</p><p><b>category</b>: <span title=\"Codes:{http://example.org/fhir/CodeSystem/research-study-category observational}\">Observational study</span></p><p><b>focus</b>: <span title=\"Codes:\">Erwachsene der Stadt Leipzig</span></p><p><b>keyword</b>: <span title=\"Codes:\">Bevölkerung, Leipzig, Erwachsene</span></p><p><b>description</b>: </p><div><p>Die LIFE Adult-Studie ist eine langfristig angelegte, bevölkerungsbezogene Kohortenstudie. Stichproben aus der Leipziger Erwachsenenbevölkerung werden hinsichtlich vielfältiger Merkmale und Krankheitsrisiken umfassend untersucht. Insbesondere die Häufigkeit von Volkskrankheiten steht im Mittelpunkt der Forschungsarbeiten. Der Einfluss von Lebensstil- und Umweltfaktoren auf diese Erkrankungen wird charak​terisiert. Bisher unbekannte Risikofaktoren für die Entstehung von Volkskrankheiten sollen aufgespürt und neue Möglichkeiten der Früherkennung entwickelt werden.</p>\n</div><h3>Arms</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td></tr><tr><td style=\"display: none\">*</td><td>LIFE-Adult-Kohorte</td></tr></table></div></div>"
      },
      "extension" : [{
        "extension" : [{
          "url" : "value",
          "valueString" : "MII Modul Studie"
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.label"
      },
      {
        "extension" : [{
          "url" : "role",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://example.org/fhir/CodeSystem/associated-party-role",
              "code" : "sponsor"
            }]
          }
        },
        {
          "url" : "party",
          "valueReference" : {
            "reference" : "Organization/mii-exa-studie-author"
          }
        }],
        "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ResearchStudy.associatedParty"
      },
      {
        "extension" : [{
          "url" : "status",
          "valueString" : "genehmigt"
        },
        {
          "url" : "kommission",
          "valueString" : "Ethik-Kommission der Medizinischen Fakultät der Universität Leipzig"
        },
        {
          "url" : "ethiknummer",
          "valueString" : "159-12-21052012"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-ethikvotum"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-studienregister",
        "valueReference" : {
          "reference" : "Library/mii-exa-studie-register"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-eligibility",
        "valueReference" : {
          "reference" : "EvidenceVariable/mii-exa-studie-ein-auschluss-kriterium"
        }
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-akronym",
        "valueString" : "LIFE ADULT"
      },
      {
        "extension" : [{
          "url" : "rekrutierungsstart",
          "valueDate" : "2009-01-01"
        },
        {
          "url" : "rekrutierungsziel",
          "valueInteger" : 10000
        },
        {
          "url" : "rekrutierungsstand",
          "valueInteger" : 10000
        },
        {
          "url" : "rekrutierungsstand-genauigkeit",
          "valueString" : "good"
        },
        {
          "url" : "rekrutierungsstand-datum",
          "valueDate" : "2022-05-28"
        }],
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-rekrutierung"
      },
      {
        "url" : "https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-ex-studie-finanzierung",
        "valueString" : "Deutsches Bundesministerium für Bildung und Forschung (BMBF)"
      }],
      "identifier" : [{
        "system" : "https://example.com/fhir/sid/lha",
        "value" : "7Q6PJD8NV3-2"
      }],
      "title" : "LIFE-Adult-Study",
      "partOf" : [{
        "reference" : "ResearchStudy/mii-exa-studie-reference-study"
      }],
      "status" : "active",
      "category" : [{
        "coding" : [{
          "system" : "http://example.org/fhir/CodeSystem/research-study-category",
          "code" : "observational"
        }]
      }],
      "focus" : [{
        "text" : "Erwachsene der Stadt Leipzig"
      }],
      "keyword" : [{
        "text" : "Bevölkerung, Leipzig, Erwachsene"
      }],
      "description" : "Die LIFE Adult-Studie ist eine langfristig angelegte, bevölkerungsbezogene Kohortenstudie. Stichproben aus der Leipziger Erwachsenenbevölkerung werden hinsichtlich vielfältiger Merkmale und Krankheitsrisiken umfassend untersucht. Insbesondere die Häufigkeit von Volkskrankheiten steht im Mittelpunkt der Forschungsarbeiten. Der Einfluss von Lebensstil- und Umweltfaktoren auf diese Erkrankungen wird charak​terisiert. Bisher unbekannte Risikofaktoren für die Entstehung von Volkskrankheiten sollen aufgespürt und neue Möglichkeiten der Früherkennung entwickelt werden.",
      "arm" : [{
        "name" : "LIFE-Adult-Kohorte"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Cohort"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Proband/mii-exa-studie-proband",
    "resource" : {
      "resourceType" : "ResearchSubject",
      "id" : "mii-exa-studie-proband",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-proband"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"ResearchSubject_mii-exa-studie-proband\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchSubject mii-exa-studie-proband</b></p><a name=\"mii-exa-studie-proband\"> </a><a name=\"hcmii-exa-studie-proband\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-proband.html\">MII PR Studie Proband</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>identifier</b>: Anonymous identifier/321123456</p><p><b>status</b>: Candidate</p><p><b>period</b>: 2023-01-01 --&gt; 2023-12-31</p><p><b>study</b>: <a href=\"ResearchStudy-mii-exa-studie-cohort.html\">ResearchStudy LIFE-Adult-Study</a></p><p><b>individual</b>: <a href=\"Patient-mii-exa-studie-patient.html\">Jane Doe  Female, DoB: 1980-11-12 ( Krankenversichertennummer (use: official, ))</a></p><p><b>consent</b>: <a href=\"Consent-mii-exa-studie-consent.html\">mii-exa-studie-consent</a></p></div></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "ANON"
          }]
        },
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/patienten",
        "value" : "321123456"
      }],
      "status" : "candidate",
      "period" : {
        "start" : "2023-01-01",
        "end" : "2023-12-31"
      },
      "study" : {
        "reference" : "ResearchStudy/mii-exa-studie-cohort"
      },
      "individual" : {
        "reference" : "Patient/mii-exa-studie-patient"
      },
      "consent" : {
        "reference" : "Consent/mii-exa-studie-consent"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Proband"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Beteiligte_Person/mii-exa-studie-beteiligte-person",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "mii-exa-studie-beteiligte-person",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-beteiligte-person"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"PractitionerRole_mii-exa-studie-beteiligte-person\"> </a><p class=\"res-header-id\"><b>Generated Narrative: PractitionerRole mii-exa-studie-beteiligte-person</b></p><a name=\"mii-exa-studie-beteiligte-person\"> </a><a name=\"hcmii-exa-studie-beteiligte-person\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-studie-beteiligte-person.html\">MII PR Studie Beteiligte Person</a></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>practitioner</b>: <a href=\"Practitioner-mii-exa-studie-practitioner.html\">Practitioner Max Mustermann </a></p><p><b>organization</b>: <a href=\"Organization-mii-exa-studie-practitioner-organization.html\">Organization Example Organization for Practitioner</a></p><p><b>code</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/practitioner-role doctor}\">Doctor</span></p><p><b>telecom</b>: ph: 0123456789</p></div></div>"
      },
      "practitioner" : {
        "reference" : "Practitioner/mii-exa-studie-practitioner"
      },
      "organization" : {
        "reference" : "Organization/mii-exa-studie-practitioner-organization"
      },
      "code" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/practitioner-role",
          "code" : "doctor"
        }]
      }],
      "telecom" : [{
        "system" : "phone",
        "value" : "0123456789"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Beteiligte_Person"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/MII_PR_Studie_Register/mii-exa-studie-register",
    "resource" : {
      "resourceType" : "Library",
      "id" : "mii-exa-studie-register",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-studie/StructureDefinition/mii-pr-studie-register"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Library_mii-exa-studie-register\"> </a><p><b style=\"color: maroon\">Exception parsing generated Narrative (see /tmp/liquid-c7517bfc-7b3d-47a9-91d9-76d37b71801d.html): unexpected non-end of element null::a  at line 105 column 50</b></p></div></div>"
      },
      "identifier" : [{
        "system" : "https://example.com/fhir/sid/drks",
        "value" : "DRKS"
      }],
      "name" : "DRKS - Deutsches Register Klinischer Studien",
      "status" : "active",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/library-type",
          "code" : "asset-collection"
        }]
      },
      "relatedArtifact" : [{
        "type" : "documentation",
        "url" : "https://drks.de/",
        "document" : {
          "url" : "https://drks.de/"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "MII_PR_Studie_Register"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-studie-author",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-studie-author",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Organization_mii-exa-studie-author\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-studie-author</b></p><a name=\"mii-exa-studie-author\"> </a><a name=\"hcmii-exa-studie-author\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>name</b>: Example Organization for Author</p></div></div>"
      },
      "name" : "Example Organization for Author"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-studie-custodian",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-studie-custodian",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Organization_mii-exa-studie-custodian\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-studie-custodian</b></p><a name=\"mii-exa-studie-custodian\"> </a><a name=\"hcmii-exa-studie-custodian\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>name</b>: Example Organization for Custodian</p></div></div>"
      },
      "name" : "Example Organization for Custodian"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Organization/mii-exa-studie-practitioner-organization",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "mii-exa-studie-practitioner-organization",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Organization_mii-exa-studie-practitioner-organization\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Organization mii-exa-studie-practitioner-organization</b></p><a name=\"mii-exa-studie-practitioner-organization\"> </a><a name=\"hcmii-exa-studie-practitioner-organization\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>name</b>: Example Organization for Practitioner</p></div></div>"
      },
      "name" : "Example Organization for Practitioner"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Practitioner/mii-exa-studie-practitioner",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-studie-practitioner",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Practitioner_mii-exa-studie-practitioner\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-studie-practitioner</b></p><a name=\"mii-exa-studie-practitioner\"> </a><a name=\"hcmii-exa-studie-practitioner\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>name</b>: Max Mustermann </p></div></div>"
      },
      "name" : [{
        "family" : "Mustermann",
        "given" : ["Max"]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/ResearchStudy/mii-exa-studie-reference-study",
    "resource" : {
      "resourceType" : "ResearchStudy",
      "id" : "mii-exa-studie-reference-study",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"ResearchStudy_mii-exa-studie-reference-study\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ResearchStudy mii-exa-studie-reference-study</b></p><a name=\"mii-exa-studie-reference-study\"> </a><a name=\"hcmii-exa-studie-reference-study\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p><b>title</b>: Example Reference Study</p><p><b>status</b>: Completed</p></div></div>"
      },
      "title" : "Example Reference Study",
      "status" : "completed"
    },
    "request" : {
      "method" : "POST",
      "url" : "ResearchStudy"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Patient/mii-exa-studie-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-studie-patient",
      "meta" : {
        "profile" : ["http://fhir.de/ConsentManagement/StructureDefinition/Patient"],
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Patient_mii-exa-studie-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-studie-patient</b></p><a name=\"mii-exa-studie-patient\"> </a><a name=\"hcmii-exa-studie-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <code>http://fhir.de/ConsentManagement/StructureDefinition/Patient</code></p><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Jane Doe  Female, DoB: 1980-11-12 ( Krankenversichertennummer (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">false</td></tr></table></div></div>"
      },
      "identifier" : [{
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "KVZ10"
          }]
        },
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "D92345678"
      }],
      "name" : [{
        "family" : "Doe",
        "given" : ["Jane"]
      }],
      "gender" : "female",
      "birthDate" : "1980-11-12",
      "deceasedBoolean" : false
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/Consent/mii-exa-studie-consent",
    "resource" : {
      "resourceType" : "Consent",
      "id" : "mii-exa-studie-consent",
      "meta" : {
        "security" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
          "code" : "HTEST",
          "display" : "test health data"
        }]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"de\" lang=\"de\"><hr/><p><b>German</b></p><hr/><a name=\"Consent_mii-exa-studie-consent\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent mii-exa-studie-consent</b></p><a name=\"mii-exa-studie-consent\"> </a><a name=\"hcmii-exa-studie-consent\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Security Label: <a href=\"http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html\">test health data (Details: ActReason code HTEST = 'test health data')</a></p></div><h2>Participants</h2><table class=\"grid\"><tr><td><b>Role</b></td><td><b>Details</b></td></tr><tr><td title=\"Who the consent applies to\">Patient</td><td><a href=\"Patient-mii-exa-studie-patient.html\">Jane Doe  Female, DoB: 1980-11-12 ( Krankenversichertennummer (use: official, ))</a></td></tr></table><p>This consent is made under the policy <code>urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791</code> .</p><p>The subject has given their consent.</p></div></div>"
      },
      "status" : "active",
      "scope" : {
        "coding" : [{
          "code" : "research"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "59284-0"
        }]
      }],
      "patient" : {
        "reference" : "Patient/mii-exa-studie-patient"
      },
      "policy" : [{
        "uri" : "urn:oid:2.16.840.1.113883.3.1937.777.24.2.1791"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Consent"
    }
  }]
}

```
