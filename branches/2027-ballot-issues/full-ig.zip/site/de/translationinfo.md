# Übersetzungsinformationen - MII Implementation Guide Medizinisches Forschungsvorhaben v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* **Übersetzungsinformationen**

## Übersetzungsinformationen

Dieser Leitfaden ist **deutschsprachig** (Standardsprache, „DE First" gemäß KDS-Governance §4.4 und Release-2027-Planung); **Englisch** ist die Übersetzung. Über den Sprachumschalter oben rechts wechseln Sie zwischen `/de/` und `/en/`.

Die englischen Seiten stammen aus dem englischen 2027-Guide-Baum der Modulverantwortlichen (menschliche Übersetzung, keine Maschinenübersetzung); FHIR-Artefakt-Bezeichner bleiben englisch.

