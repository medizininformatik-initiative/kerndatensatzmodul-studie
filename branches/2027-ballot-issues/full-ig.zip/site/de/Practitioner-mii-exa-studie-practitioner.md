# mii-exa-studie-practitioner - MII Implementation Guide Medizinisches Forschungsvorhaben v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-studie-practitioner**

## Beispiel Practitioner: mii-exa-studie-practitioner

-------

**German**

-------

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html)

**name**: Max Mustermann 



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-studie-practitioner",
  "meta" : {
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST",
      "display" : "test health data"
    }]
  },
  "name" : [{
    "family" : "Mustermann",
    "given" : ["Max"]
  }]
}

```
